package biyDaalt;

import java.io.*;
import java.util.ArrayList;

public class Registration {
    private ArrayList<Student> studentList = new ArrayList<>();
    private ArrayList<Subject> subjectList = new ArrayList<>();
    private ArrayList<Major> majorList = new ArrayList<>();

    // Load subjects from file
    public void loadSubjects(String fileName) throws IOException {
        BufferedReader input = new BufferedReader(new FileReader(fileName));
        String line;
        while ((line = input.readLine()) != null) {
            String[] values = line.split("/");
            subjectList.add(new Subject(values[0], values[1], Float.parseFloat(values[2])));
        }
        input.close();
    }

    // Load majors from file
    public void loadMajors(String fileName) throws IOException {
        BufferedReader input = new BufferedReader(new FileReader(fileName));
        String line;
        while ((line = input.readLine()) != null) {
            String[] values = line.split("/");
            majorList.add(new Major(values[0], values[1]));
        }
        input.close();
    }

    // Load exam results from file
    public void loadExams(String fileName) throws IOException {
        BufferedReader input = new BufferedReader(new FileReader(fileName));
        String line;
        while ((line = input.readLine()) != null) {
            String[] values = line.split("/");
            String studentCode = values[0];
            String subjectCode = values[1];
            int score = Integer.parseInt(values[2]);

            Student student = findOrCreateStudent(studentCode);
            Subject subject = findSubjectByCode(subjectCode);

            if (subject == null) {
                System.out.println("Subject not found: " + subjectCode);
                continue; // Skip invalid subject
            }
            if (score < 0 || score > 100) {
                System.out.println("Invalid score for student " + studentCode + ": " + score);
                continue; // Skip invalid score
            }

            student.addLesson(new Lessons(subject, score));
        }
        input.close();
    }

    // Helper methods
    private Student findOrCreateStudent(String studentCode) {
        for (Student student : studentList) {
            if (student.getStudentCode().equals(studentCode)) {
                return student;
            }
        }
        Student newStudent = new Student(studentCode);
        studentList.add(newStudent);
        return newStudent;
    }

    private Subject findSubjectByCode(String subjectCode) {
        for (Subject subject : subjectList) {
            if (subject.getSubjectCode().equals(subjectCode)) {
                return subject;
            }
        }
        return null;
    }

    // Display methods
    public void displaySubjects() {
        for (Subject subject : subjectList) {
            System.out.println(subject);
        }
    }

    public void displayMajors() {
        for (Major major : majorList) {
            System.out.println(major);
        }
    }

    public void displayStudentGPAs() {
        for (Student student : studentList) {
            System.out.println(student);
        }
    }

    // Display failing students (with more than 3 fails)
    public void displayFailingStudents() {
        ArrayList<Student> failingStudents = new ArrayList<>();

        for (Student student : studentList) {
            if (student.hasMoreThanThreeFails()) {
                failingStudents.add(student);
            }
        }

        if (failingStudents.isEmpty()) {
            System.out.println("0");
        } else {
            for (Student student : failingStudents) {
                System.out.println("Failing Student: " + student.getStudentCode() + " - GPA: " + String.format("%.2f", student.getGPA()));
            }
        }
    }

    // Calculate average GPA
    public float calculateAverageGPA() {
        float totalGPA = 0;
        for (Student student : studentList) {
            totalGPA += student.getGPA();
        }
        return studentList.size() == 0 ? 0 : totalGPA / studentList.size();
    }

    // Main method
    public static void main(String[] args) {
        try {
            Registration registration = new Registration();
            registration.loadSubjects("src/biyDaalt/Subjects.txt");
            registration.loadMajors("src/biyDaalt/Professions.txt");
            registration.loadExams("src/biyDaalt/Exams.txt");

            System.out.println("Subjects:");
            registration.displaySubjects();

            System.out.println("\nMajors:");
            registration.displayMajors();

            System.out.println("\nStudent GPAs:");
            registration.displayStudentGPAs();

            System.out.println("\nStudents with more than 3 failing grades:");
            registration.displayFailingStudents();

            System.out.println("\nAverage GPA: " + String.format("%.2f", registration.calculateAverageGPA()));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
