package biyDaalt;

import java.util.ArrayList;

public class Student {
    private String studentCode;
    private float GPA;
    private ArrayList<Lessons> lessons;

    public Student(String studentCode) {
        this.studentCode = studentCode;
        this.lessons = new ArrayList<>();
    }

    public String getStudentCode() { return studentCode; }
    public float getGPA() { return GPA; }

    public void calculateGPA() {
        float totalPoints = 0;
        float totalCredits = 0;
        for (Lessons lesson : lessons) {
            totalPoints += lesson.getScore() * lesson.getLearned().getCredit();
            totalCredits += lesson.getLearned().getCredit();
        }
        if (totalCredits != 0) {
            this.GPA = totalPoints / totalCredits;
        }
    }

    public void addLesson(Lessons lesson) {
        lessons.add(lesson);
        calculateGPA();
    }

    public boolean hasMoreThanThreeFails() {
        int failCount = 0;
        for (Lessons lesson : lessons) {
            if (lesson.getScore() < 60) {  // Assuming 'F' is less than 60
                failCount++;
            }
        }
        return failCount >= 3;
    }

    @Override
    public String toString() {
        return studentCode + " - GPA: " + String.format("%.2f", GPA);
    }
}
